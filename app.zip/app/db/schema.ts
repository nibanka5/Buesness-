import {
  bigint,
  boolean,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export const listings = mysqlTable(
  "listings",
  {
    id: serial("id").primaryKey(),
    ownerId: bigint("ownerId", { mode: "number", unsigned: true }),
    slug: varchar("slug", { length: 180 }).notNull().unique(),
    name: varchar("name", { length: 120 }).notNull(),
    category: varchar("category", { length: 80 }).notNull(),
    description: text("description").notNull(),
    phone: varchar("phone", { length: 24 }).notNull(),
    whatsapp: varchar("whatsapp", { length: 20 }).notNull(),
    website: text("website"),
    address: varchar("address", { length: 240 }).notNull(),
    district: varchar("district", { length: 80 }).notNull(),
    city: varchar("city", { length: 80 }).notNull(),
    openingHours: text("openingHours").notNull(),
    services: json("services").$type<string[]>().notNull(),
    photos: json("photos").$type<string[]>().notNull(),
    mapQuery: varchar("mapQuery", { length: 240 }).notNull(),
    status: mysqlEnum("status", ["pending", "approved", "rejected"])
      .default("pending")
      .notNull(),
    featured: boolean("featured").default(false).notNull(),
    requestedFeatured: boolean("requestedFeatured").default(false).notNull(),
    verified: boolean("verified").default(false).notNull(),
    sample: boolean("sample").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (table) => ({
    statusIdx: index("listings_status_idx").on(table.status),
    categoryIdx: index("listings_category_idx").on(table.category),
    districtIdx: index("listings_district_idx").on(table.district),
    ownerIdx: index("listings_owner_idx").on(table.ownerId),
  }),
);

export const inquiries = mysqlTable("inquiries", {
  id: serial("id").primaryKey(),
  listingId: bigint("listingId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 24 }),
  message: text("message").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const reports = mysqlTable("reports", {
  id: serial("id").primaryKey(),
  listingId: bigint("listingId", { mode: "number", unsigned: true }).notNull(),
  reason: varchar("reason", { length: 120 }).notNull(),
  details: text("details").notNull(),
  email: varchar("email", { length: 320 }),
  status: mysqlEnum("status", ["open", "resolved"]).default("open").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const contactMessages = mysqlTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const directorySettings = mysqlTable("directory_settings", {
  id: serial("id").primaryKey(),
  featuredPriceLkr: int("featuredPriceLkr").default(2500).notNull(),
  featuredDurationDays: int("featuredDurationDays").default(30).notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Listing = typeof listings.$inferSelect;
export type InsertListing = typeof listings.$inferInsert;
