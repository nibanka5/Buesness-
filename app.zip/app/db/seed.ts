import { eq } from "drizzle-orm";
import { getDb } from "../api/queries/connection";
import { directorySettings, listings } from "./schema";

const sampleListings = [
  {
    slug: "sample-cinnamon-leaf-kitchen",
    name: "Cinnamon Leaf Kitchen",
    category: "Restaurants",
    description: "A fictional sample restaurant profile showing how a local dining business can present its menu, hours and direct contact options.",
    phone: "+94 11 000 0000",
    whatsapp: "94110000000",
    website: "https://example.com",
    address: "Sample address, Colombo 00300",
    district: "Colombo",
    city: "Colombo",
    openingHours: "Monday–Sunday, 11:00–22:00 (sample hours)",
    services: ["Sri Lankan meals", "Group dining", "Takeaway"],
    photos: ["/images/cinnamon-kitchen.webp"],
    mapQuery: "Colombo, Sri Lanka",
    status: "approved" as const,
    featured: true,
    requestedFeatured: false,
    verified: false,
    sample: true,
  },
  {
    slug: "sample-lagoon-courtyard-hotel",
    name: "Lagoon Courtyard Hotel",
    category: "Hotels",
    description: "A fictional sample stay profile demonstrating room information, visitor enquiries and map-based directions for a hospitality business.",
    phone: "+94 91 000 0000",
    whatsapp: "94910000000",
    website: "https://example.com",
    address: "Sample address, Galle 80000",
    district: "Galle",
    city: "Galle",
    openingHours: "Reception open 24 hours (sample hours)",
    services: ["Garden rooms", "Breakfast", "Airport transfers"],
    photos: ["/images/lagoon-hotel.webp"],
    mapQuery: "Galle, Sri Lanka",
    status: "approved" as const,
    featured: true,
    requestedFeatured: false,
    verified: false,
    sample: true,
  },
  {
    slug: "sample-nilaveli-glow-studio",
    name: "Nilaveli Glow Studio",
    category: "Beauty Salons",
    description: "A fictional sample salon profile illustrating service lists, opening times and direct appointment enquiries for a beauty business.",
    phone: "+94 26 000 0000",
    whatsapp: "94260000000",
    website: "https://example.com",
    address: "Sample address, Trincomalee 31000",
    district: "Trincomalee",
    city: "Trincomalee",
    openingHours: "Tuesday–Sunday, 09:00–19:00 (sample hours)",
    services: ["Hair styling", "Bridal preparation", "Skin care"],
    photos: ["/images/glow-salon.webp"],
    mapQuery: "Trincomalee, Sri Lanka",
    status: "approved" as const,
    featured: false,
    requestedFeatured: false,
    verified: false,
    sample: true,
  },
  {
    slug: "sample-kandy-tool-house",
    name: "Kandy Tool House",
    category: "Hardware",
    description: "A fictional sample hardware profile showing product categories, direct calls and location details for a neighbourhood supplier.",
    phone: "+94 81 000 0000",
    whatsapp: "94810000000",
    website: "https://example.com",
    address: "Sample address, Kandy 20000",
    district: "Kandy",
    city: "Kandy",
    openingHours: "Monday–Saturday, 08:00–18:00 (sample hours)",
    services: ["Hand tools", "Paint supplies", "Trade orders"],
    photos: ["/images/tool-house.webp"],
    mapQuery: "Kandy, Sri Lanka",
    status: "approved" as const,
    featured: false,
    requestedFeatured: false,
    verified: false,
    sample: true,
  },
  {
    slug: "sample-green-lane-auto-care",
    name: "Green Lane Auto Care",
    category: "Vehicle Services",
    description: "A fictional sample vehicle service profile demonstrating workshop services, contact actions and customer enquiry tools.",
    phone: "+94 38 000 0000",
    whatsapp: "94380000000",
    website: "https://example.com",
    address: "Sample address, Negombo 11500",
    district: "Gampaha",
    city: "Negombo",
    openingHours: "Monday–Saturday, 08:30–17:30 (sample hours)",
    services: ["Vehicle inspection", "Oil service", "Battery checks"],
    photos: ["/images/auto-care.webp"],
    mapQuery: "Negombo, Sri Lanka",
    status: "approved" as const,
    featured: true,
    requestedFeatured: false,
    verified: false,
    sample: true,
  },
  {
    slug: "sample-southern-spice-table",
    name: "Southern Spice Table",
    category: "Restaurants",
    description: "A fictional sample food business profile showing how regional restaurants can share signature services and connect with nearby customers.",
    phone: "+94 41 000 0000",
    whatsapp: "94410000000",
    website: "https://example.com",
    address: "Sample address, Matara 81000",
    district: "Matara",
    city: "Matara",
    openingHours: "Wednesday–Monday, 10:30–21:30 (sample hours)",
    services: ["Rice and curry", "Family meals", "Catering"],
    photos: ["/images/southern-table.webp"],
    mapQuery: "Matara, Sri Lanka",
    status: "approved" as const,
    featured: false,
    requestedFeatured: false,
    verified: false,
    sample: true,
  },
];

async function seed() {
  const db = getDb();
  console.log("Seeding directory...");

  const existingSamples = await db
    .select({ id: listings.id })
    .from(listings)
    .where(eq(listings.sample, true))
    .limit(1);

  if (existingSamples.length === 0) {
    await db.insert(listings).values(sampleListings);
    console.log(`Added ${sampleListings.length} fictional sample listings.`);
  } else {
    console.log("Sample listings already present; no duplicates added.");
  }

  const settings = await db.select().from(directorySettings).limit(1);
  if (settings.length === 0) {
    await db.insert(directorySettings).values({
      featuredPriceLkr: 2500,
      featuredDurationDays: 30,
    });
  }

  console.log("Done.");
  process.exit(0);
}

seed().catch((error) => {
  console.error(error);
  process.exit(1);
});
