import { and, desc, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { listingInputSchema, slugify } from "@contracts/directory";
import { listings } from "@db/schema";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";

export const ownerRouter = createRouter({
  mine: authedQuery.query(async ({ ctx }) => {
    return getDb()
      .select()
      .from(listings)
      .where(eq(listings.ownerId, ctx.user.id))
      .orderBy(desc(listings.updatedAt));
  }),

  create: authedQuery.input(listingInputSchema).mutation(async ({ ctx, input }) => {
    const slug = `${slugify(input.name)}-${Date.now().toString(36)}`;
    const [result] = await getDb()
      .insert(listings)
      .values({
        ...input,
        slug,
        ownerId: ctx.user.id,
        status: "pending",
        featured: false,
        verified: false,
        sample: false,
      })
      .$returningId();
    return { id: result.id, slug };
  }),

  update: authedQuery
    .input(z.object({ id: z.number().int().positive(), data: listingInputSchema }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db
        .select({ id: listings.id, ownerId: listings.ownerId })
        .from(listings)
        .where(eq(listings.id, input.id))
        .limit(1);
      if (!existing[0] || existing[0].ownerId !== ctx.user.id) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Listing not found" });
      }
      await db
        .update(listings)
        .set({ ...input.data, status: "pending", verified: false })
        .where(and(eq(listings.id, input.id), eq(listings.ownerId, ctx.user.id)));
      return { ok: true };
    }),
});
