import type { Context } from "hono";
import { eq } from "drizzle-orm";
import { CATEGORIES, DISTRICTS, slugify } from "@contracts/directory";
import { listings } from "@db/schema";
import { getDb } from "../queries/connection";

function xmlEscape(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

export async function sitemap(c: Context) {
  const origin = new URL(c.req.url).origin;
  const businessRows = await getDb()
    .select({ slug: listings.slug, updatedAt: listings.updatedAt })
    .from(listings)
    .where(eq(listings.status, "approved"));
  const staticPaths = ["", "/search", "/categories", "/districts", "/contact", "/privacy", "/terms"];
  const paths = [
    ...staticPaths,
    ...CATEGORIES.map((category) => `/category/${slugify(category)}`),
    ...DISTRICTS.map((district) => `/district/${slugify(district)}`),
  ];
  const urls = [
    ...paths.map((path) => ({ loc: `${origin}${path}`, lastmod: undefined })),
    ...businessRows.map((row) => ({
      loc: `${origin}/business/${row.slug}`,
      lastmod: row.updatedAt.toISOString(),
    })),
  ];
  const body = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
    .map(
      (url) =>
        `  <url><loc>${xmlEscape(url.loc)}</loc>${url.lastmod ? `<lastmod>${url.lastmod}</lastmod>` : ""}</url>`,
    )
    .join("\n")}\n</urlset>`;
  return c.body(body, 200, { "Content-Type": "application/xml; charset=utf-8" });
}

export function robots(c: Context) {
  const origin = new URL(c.req.url).origin;
  return c.text(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /owner\nSitemap: ${origin}/sitemap.xml\n`);
}
