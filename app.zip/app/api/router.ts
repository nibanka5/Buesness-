import { authRouter } from "./auth-router";
import { directoryRouter } from "./directory-router";
import { ownerRouter } from "./owner-router";
import { adminRouter } from "./admin-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  directory: directoryRouter,
  owner: ownerRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
