import { and, desc, eq, like, or } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { CATEGORIES, DISTRICTS } from "@contracts/directory";
import { contactMessages, directorySettings, inquiries, listings, reports } from "@db/schema";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";

const optionalText = (max: number) => z.union([z.string().trim().max(max), z.literal("")]);

export const directoryRouter = createRouter({
  metadata: publicQuery.query(async () => {
    const db = getDb();
    const rows = await db
      .select({
        category: listings.category,
        district: listings.district,
        featured: listings.featured,
      })
      .from(listings)
      .where(eq(listings.status, "approved"));
    const settings = await db.select().from(directorySettings).limit(1);

    return {
      total: rows.length,
      categoryCounts: Object.fromEntries(
        CATEGORIES.map((category) => [
          category,
          rows.filter((row) => row.category === category).length,
        ]),
      ),
      districtCounts: Object.fromEntries(
        DISTRICTS.map((district) => [
          district,
          rows.filter((row) => row.district === district).length,
        ]),
      ),
      settings: settings[0] ?? { featuredPriceLkr: 2500, featuredDurationDays: 30 },
    };
  }),

  search: publicQuery
    .input(
      z.object({
        q: z.string().trim().max(100).optional().default(""),
        category: z.enum(CATEGORIES).optional(),
        district: z.enum(DISTRICTS).optional(),
        limit: z.number().int().min(1).max(60).optional().default(40),
      }),
    )
    .query(async ({ input }) => {
      const conditions = [eq(listings.status, "approved")];
      if (input.category) conditions.push(eq(listings.category, input.category));
      if (input.district) conditions.push(eq(listings.district, input.district));
      if (input.q) {
        const term = `%${input.q.replace(/[%_]/g, "")}%`;
        const search = or(
          like(listings.name, term),
          like(listings.category, term),
          like(listings.district, term),
          like(listings.city, term),
          like(listings.description, term),
          like(listings.address, term),
          like(listings.services, term),
        );
        if (search) conditions.push(search);
      }

      return getDb()
        .select()
        .from(listings)
        .where(and(...conditions))
        .orderBy(desc(listings.featured), desc(listings.createdAt))
        .limit(input.limit);
    }),

  bySlug: publicQuery
    .input(z.object({ slug: z.string().trim().min(1).max(180) }))
    .query(async ({ input }) => {
      const rows = await getDb()
        .select()
        .from(listings)
        .where(and(eq(listings.slug, input.slug), eq(listings.status, "approved")))
        .limit(1);
      if (!rows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Listing not found" });
      return rows[0];
    }),

  submitInquiry: publicQuery
    .input(
      z.object({
        listingId: z.number().int().positive(),
        name: z.string().trim().min(2).max(100),
        email: z.string().trim().email().max(320),
        phone: optionalText(24),
        message: z.string().trim().min(10).max(1600),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const listing = await db
        .select({ id: listings.id })
        .from(listings)
        .where(and(eq(listings.id, input.listingId), eq(listings.status, "approved")))
        .limit(1);
      if (!listing[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Listing not found" });
      await db.insert(inquiries).values(input);
      return { ok: true };
    }),

  reportListing: publicQuery
    .input(
      z.object({
        listingId: z.number().int().positive(),
        reason: z.string().trim().min(3).max(120),
        details: z.string().trim().min(10).max(1200),
        email: z.union([z.string().trim().email().max(320), z.literal("")]),
      }),
    )
    .mutation(async ({ input }) => {
      await getDb().insert(reports).values(input);
      return { ok: true };
    }),

  contact: publicQuery
    .input(
      z.object({
        name: z.string().trim().min(2).max(100),
        email: z.string().trim().email().max(320),
        message: z.string().trim().min(10).max(1600),
      }),
    )
    .mutation(async ({ input }) => {
      await getDb().insert(contactMessages).values(input);
      return { ok: true };
    }),
});
