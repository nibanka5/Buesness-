import { desc, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { listingInputSchema } from "@contracts/directory";
import { directorySettings, inquiries, listings, reports } from "@db/schema";
import { adminQuery, createRouter } from "./middleware";
import { getDb } from "./queries/connection";

export const adminRouter = createRouter({
  listings: adminQuery.query(async () => {
    return getDb().select().from(listings).orderBy(desc(listings.createdAt));
  }),

  moderate: adminQuery
    .input(
      z.object({
        id: z.number().int().positive(),
        action: z.enum(["approve", "reject", "verify", "unverify", "feature", "unfeature", "remove"]),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      if (input.action === "remove") {
        await db.transaction(async (tx) => {
          await tx.delete(inquiries).where(eq(inquiries.listingId, input.id));
          await tx.delete(reports).where(eq(reports.listingId, input.id));
          const removed = await tx.delete(listings).where(eq(listings.id, input.id));
          if (removed[0].affectedRows === 0) {
            throw new TRPCError({ code: "NOT_FOUND", message: "Listing not found" });
          }
        });
        return { ok: true };
      }

      const changes = {
        approve: { status: "approved" as const },
        reject: { status: "rejected" as const, featured: false },
        verify: { verified: true },
        unverify: { verified: false },
        feature: { featured: true, status: "approved" as const },
        unfeature: { featured: false },
      }[input.action];
      const updated = await db.update(listings).set(changes).where(eq(listings.id, input.id));
      if (updated[0].affectedRows === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Listing not found" });
      }
      return { ok: true };
    }),

  updateListing: adminQuery
    .input(z.object({ id: z.number().int().positive(), data: listingInputSchema }))
    .mutation(async ({ input }) => {
      const updated = await getDb()
        .update(listings)
        .set(input.data)
        .where(eq(listings.id, input.id));
      if (updated[0].affectedRows === 0) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Listing not found" });
      }
      return { ok: true };
    }),

  updateSettings: adminQuery
    .input(
      z.object({
        featuredPriceLkr: z.number().int().min(0).max(1_000_000),
        featuredDurationDays: z.number().int().min(1).max(365),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const current = await db.select().from(directorySettings).limit(1);
      if (current[0]) {
        await db.update(directorySettings).set(input).where(eq(directorySettings.id, current[0].id));
      } else {
        await db.insert(directorySettings).values(input);
      }
      return { ok: true };
    }),
});
