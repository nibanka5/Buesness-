import { Link, useSearchParams } from "react-router";
import { ArrowRight, SearchX, SlidersHorizontal, X } from "lucide-react";
import { CATEGORIES, DISTRICTS } from "@contracts/directory";
import { trpc } from "@/providers/trpc";
import { usePageMeta } from "@/hooks/usePageMeta";
import { SearchPanel } from "@/components/SearchPanel";
import { BusinessCard, BusinessCardSkeleton } from "@/components/BusinessCard";

export default function SearchPage() {
  const [params] = useSearchParams();
  const q = params.get("q")?.trim() ?? "";
  const category = CATEGORIES.find((item) => item === params.get("category"));
  const district = DISTRICTS.find((item) => item === params.get("district"));
  const results = trpc.directory.search.useQuery({ q, category, district, limit: 60 });
  const hasFilters = Boolean(q || category || district);

  usePageMeta(
    q ? `${q} — Search | Lanka Business Finder` : "Find Local Businesses | Lanka Business Finder",
    "Search Sri Lankan businesses by name, service, keyword, category, district or city.",
  );

  return (
    <>
      <section className="border-b border-[var(--line)] bg-[var(--emerald-soft)]/45 py-9 md:py-14">
        <div className="container-shell">
          <p className="eyebrow text-[var(--emerald-dark)]">Directory search</p>
          <h1 className="display-title mt-3 text-[36px] md:text-[52px]">Find the right local connection.</h1>
          <p className="mb-7 mt-3 max-w-[65ch] text-[15px] text-[var(--muted-ink)]">Search by business name, category, district, city, service or keyword.</p>
          <SearchPanel initialQuery={q} initialCategory={category} initialDistrict={district} compact />
        </div>
      </section>

      <section className="container-shell py-10 md:py-16" aria-live="polite">
        <div className="mb-6 flex flex-col gap-4 border-b border-[var(--line)] pb-5 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-[15px] font-medium">
              {results.isLoading ? "Searching the directory…" : `${results.data?.length ?? 0} ${results.data?.length === 1 ? "business" : "businesses"} found`}
            </p>
            <p className="mt-1 text-[13px] text-[var(--muted-ink)]">All current results are clearly marked fictional sample data.</p>
          </div>
          {hasFilters && (
            <div className="flex flex-wrap items-center gap-2">
              <SlidersHorizontal size={16} className="text-[var(--muted-ink)]" aria-hidden="true" />
              {q && <span className="chip">“{q}”</span>}
              {category && <span className="chip">{category}</span>}
              {district && <span className="chip">{district}</span>}
              <Link to="/search" className="chip min-h-11 hover:border-[var(--emerald)]" aria-label="Clear all filters"><X size={15} /> Clear</Link>
            </div>
          )}
        </div>

        <div className="grid gap-4 lg:grid-cols-2">
          {results.isLoading && Array.from({ length: 4 }, (_, index) => <BusinessCardSkeleton key={index} />)}
          {results.data?.map((listing) => <BusinessCard key={listing.id} listing={listing} />)}
        </div>

        {results.isError && (
          <div role="alert" className="rounded-[14px] border border-red-200 bg-red-50 p-6 text-red-900">
            <h2 className="text-lg font-semibold">We couldn’t load the directory.</h2>
            <p className="mt-2 text-sm">Check your connection and try again.</p>
            <button className="btn-outline mt-4" onClick={() => results.refetch()}>Try again</button>
          </div>
        )}

        {!results.isLoading && !results.isError && results.data?.length === 0 && (
          <div className="mx-auto max-w-xl py-14 text-center">
            <SearchX className="mx-auto text-[var(--emerald-dark)]" size={38} strokeWidth={1.4} aria-hidden="true" />
            <h2 className="display-title mt-5 text-[30px]">No sample profiles match yet.</h2>
            <p className="mx-auto mt-3 max-w-[50ch] text-[15px] text-[var(--muted-ink)]">Try a broader keyword or clear a filter. Real owner submissions will appear here after administrator approval.</p>
            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
              <Link to="/search" className="btn-primary">Clear filters</Link>
              <Link to="/owner" className="btn-outline">List a business <ArrowRight size={17} /></Link>
            </div>
          </div>
        )}
      </section>
    </>
  );
}
