import { Link } from "react-router";
import { ArrowUpRight } from "lucide-react";
import { CATEGORIES, slugify } from "@contracts/directory";
import { trpc } from "@/providers/trpc";
import { usePageMeta } from "@/hooks/usePageMeta";

export default function CategoriesPage() {
  usePageMeta("Business Categories | Lanka Business Finder", "Browse 12 business and service categories across Sri Lanka.");
  const metadata = trpc.directory.metadata.useQuery();

  return (
    <section className="container-shell py-10 md:py-16">
      <div className="max-w-3xl">
        <p className="eyebrow text-[var(--emerald-dark)]">12 ways to find local</p>
        <h1 className="display-title mt-3 text-[40px] md:text-[58px]">Browse by category.</h1>
        <p className="mt-4 max-w-[65ch] text-[16px] text-[var(--muted-ink)]">From everyday services to specialist professionals, start with what you need and then narrow by district.</p>
      </div>
      <div className="mt-10 border-t border-[var(--line)]">
        {CATEGORIES.map((category, index) => {
          const count = metadata.data?.categoryCounts[category as keyof typeof metadata.data.categoryCounts] ?? 0;
          return (
            <Link key={category} to={`/category/${slugify(category)}`} className="group grid min-h-[82px] grid-cols-[36px_1fr_auto] items-center gap-3 border-b border-[var(--line)] py-4 transition-colors hover:bg-[var(--emerald-soft)]/50 md:grid-cols-[64px_1fr_120px_32px] md:px-3">
              <span className="font-mono text-[12px] text-[var(--gold)]">{String(index + 1).padStart(2, "0")}</span>
              <h2 className="text-[20px] font-[570] tracking-[-0.035em] md:text-[24px]">{category}</h2>
              <span className="hidden font-mono text-[12px] text-[var(--muted-ink)] md:block">{count} sample {count === 1 ? "profile" : "profiles"}</span>
              <ArrowUpRight className="arrow-nudge text-[var(--muted-ink)]" size={20} />
            </Link>
          );
        })}
      </div>
      <p className="mt-6 text-[13px] text-[var(--muted-ink)]">Counts in this demo reflect fictional sample profiles only. New submissions appear after approval.</p>
    </section>
  );
}
