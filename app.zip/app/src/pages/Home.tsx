import { Link } from "react-router";
import { ArrowRight, ArrowUpRight, BriefcaseBusiness, CarFront, GraduationCap, Hammer, HardHat, Hotel, KeyRound, MonitorCog, Scissors, ShoppingBag, Stethoscope, Utensils } from "lucide-react";
import { CATEGORIES, DISTRICTS, slugify } from "@contracts/directory";
import { trpc } from "@/providers/trpc";
import { usePageMeta } from "@/hooks/usePageMeta";
import { SearchPanel } from "@/components/SearchPanel";
import { BusinessCard, BusinessCardSkeleton } from "@/components/BusinessCard";

const categoryIcons = [Utensils, Hotel, Stethoscope, GraduationCap, Scissors, Hammer, HardHat, KeyRound, CarFront, MonitorCog, ShoppingBag, BriefcaseBusiness];

export default function Home() {
  usePageMeta(
    "Lanka Business Finder — Find Local Sri Lankan Businesses",
    "Search local businesses and services across all 25 Sri Lankan districts. Find contact details, directions and direct enquiry options.",
  );
  const metadata = trpc.directory.metadata.useQuery();
  const featured = trpc.directory.search.useQuery({ q: "", limit: 4 });

  return (
    <>
      <section className="hero-texture text-white">
        <div className="container-shell grid gap-10 py-12 md:py-20 lg:grid-cols-[minmax(0,1.6fr)_minmax(280px,.7fr)] lg:items-center lg:gap-16 lg:py-24">
          <div>
            <div className="mb-6 flex items-center gap-2.5 text-[13px] text-white/85">
              <span className="status-dot !bg-[var(--gold)]" />
              <span className="eyebrow">Sri Lanka’s local business directory</span>
            </div>
            <h1 className="display-title max-w-[760px] text-[clamp(42px,7.2vw,78px)]">
              Local is closer<br className="hidden sm:block" /> than you think.
            </h1>
            <p className="mt-5 max-w-[590px] text-[17px] leading-[1.65] text-white/80 md:text-[19px]">Find Local. Connect Directly. Grow Together.</p>
            <div className="mt-8 md:mt-10">
              <SearchPanel />
              <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-[13px] text-white/75">
                <span className="text-white/55">Try:</span>
                <Link className="flex min-h-8 items-center underline decoration-white/30 underline-offset-4 hover:text-white" to="/search?category=Restaurants&district=Colombo">Restaurants in Colombo</Link>
                <Link className="flex min-h-8 items-center underline decoration-white/30 underline-offset-4 hover:text-white" to="/search?q=vehicle">Vehicle services</Link>
              </div>
            </div>
            <p className="mt-5 max-w-[65ch] text-[12px] leading-relaxed text-white/60">Demo preview: every published business profile in this release is fictional sample data. Contact actions demonstrate the interface only.</p>
          </div>

          <aside className="relative overflow-hidden rounded-[18px] border border-white/20 bg-white/[0.055] p-6 backdrop-blur-sm md:p-8" aria-label="Directory coverage">
            <div className="absolute -right-10 -top-12 size-40 rounded-full border border-[var(--gold)]/40" aria-hidden="true" />
            <p className="eyebrow text-white/65">Islandwide index</p>
            <div className="mt-8 flex items-end gap-3">
              <span className="text-[92px] font-[450] leading-[.75] tracking-[-0.08em] text-[var(--gold)]">25</span>
              <span className="pb-1 text-lg leading-tight text-white/85">districts.<br />One directory.</span>
            </div>
            <div className="my-7 h-px bg-white/15" />
            <div className="grid grid-cols-2 gap-5">
              <div>
                <p className="text-3xl font-[550] tracking-[-0.05em]">12</p>
                <p className="mt-1 text-[13px] text-white/60">business categories</p>
              </div>
              <div>
                <p className="text-3xl font-[550] tracking-[-0.05em]">{metadata.data?.total ?? "—"}</p>
                <p className="mt-1 text-[13px] text-white/60">sample profiles live</p>
              </div>
            </div>
            <Link to="/districts" className="mt-8 flex min-h-12 items-center justify-between border-t border-white/15 pt-4 text-[14px] font-medium text-white hover:text-[var(--gold)]">
              Browse your district <ArrowRight className="arrow-nudge" size={18} />
            </Link>
          </aside>
        </div>
      </section>

      <section className="container-shell py-14 md:py-24" aria-labelledby="categories-heading">
        <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="eyebrow text-[var(--emerald-dark)]">Browse by need</p>
            <h2 id="categories-heading" className="display-title mt-3 text-[34px] md:text-[46px]">What can we help you find?</h2>
          </div>
          <Link to="/categories" className="inline-flex min-h-11 items-center gap-2 self-start text-[14px] font-semibold text-[var(--emerald-dark)] md:self-auto">All categories <ArrowRight className="arrow-nudge" size={17} /></Link>
        </div>
        <div className="grid grid-cols-2 border-l border-t border-[var(--line)] sm:grid-cols-3 lg:grid-cols-4">
          {CATEGORIES.map((category, index) => {
            const Icon = categoryIcons[index];
            const count = metadata.data?.categoryCounts[category as keyof typeof metadata.data.categoryCounts];
            return (
              <Link key={category} to={`/category/${slugify(category)}`} className="group flex min-h-[142px] flex-col justify-between border-b border-r border-[var(--line)] bg-white/45 p-4 transition-colors hover:bg-[var(--emerald-soft)] sm:min-h-[158px] sm:p-5">
                <div className="flex items-start justify-between">
                  <Icon size={23} strokeWidth={1.6} className="text-[var(--emerald-dark)]" aria-hidden="true" />
                  <ArrowUpRight size={16} className="arrow-nudge text-[var(--muted-ink)]" aria-hidden="true" />
                </div>
                <div>
                  <h3 className="text-[15px] font-[590] leading-tight tracking-[-0.025em] sm:text-[17px]">{category}</h3>
                  <p className="mt-1.5 font-mono text-[11px] text-[var(--muted-ink)]">{count ?? 0} sample {count === 1 ? "listing" : "listings"}</p>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      <section className="border-y border-[var(--line)] bg-white/55">
        <div className="container-shell py-14 md:py-24" aria-labelledby="featured-heading">
          <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="eyebrow text-[var(--emerald-dark)]">Explore the directory</p>
              <h2 id="featured-heading" className="display-title mt-3 text-[34px] md:text-[46px]">Featured sample profiles</h2>
              <p className="mt-3 max-w-[65ch] text-[15px] text-[var(--muted-ink)]">Fictional businesses show how real profiles will look. They are not verified and do not represent real contact details.</p>
            </div>
            <Link to="/search" className="inline-flex min-h-11 items-center gap-2 self-start text-[14px] font-semibold text-[var(--emerald-dark)] md:self-auto">Search all <ArrowRight className="arrow-nudge" size={17} /></Link>
          </div>
          <div className="grid gap-4 lg:grid-cols-2">
            {featured.isLoading && Array.from({ length: 4 }, (_, index) => <BusinessCardSkeleton key={index} />)}
            {featured.data?.map((listing) => <BusinessCard key={listing.id} listing={listing} />)}
          </div>
          {featured.isError && <p role="alert" className="rounded-lg bg-red-50 p-4 text-red-800">The directory could not be loaded. Please refresh and try again.</p>}
        </div>
      </section>

      <section className="container-shell py-14 md:py-24" aria-labelledby="districts-heading">
        <div className="grid gap-8 lg:grid-cols-[.72fr_1.28fr] lg:gap-16">
          <div>
            <p className="eyebrow text-[var(--emerald-dark)]">From Jaffna to Matara</p>
            <h2 id="districts-heading" className="display-title mt-3 text-[34px] md:text-[46px]">Your district,<br />your local network.</h2>
            <p className="mt-5 max-w-[48ch] text-[16px] leading-relaxed text-[var(--muted-ink)]">Browse all 25 administrative districts and narrow your search to the places that matter to you.</p>
          </div>
          <div className="grid grid-cols-2 gap-x-5 sm:grid-cols-3">
            {DISTRICTS.map((district) => {
              const count = metadata.data?.districtCounts[district as keyof typeof metadata.data.districtCounts] ?? 0;
              return (
                <Link key={district} to={`/district/${slugify(district)}`} className="group flex min-h-[54px] items-center justify-between gap-2 border-b border-[var(--line)] text-[14px] font-[520] hover:text-[var(--emerald-dark)]">
                  <span>{district}</span>
                  <span className="font-mono text-[11px] text-[var(--muted-ink)]">{String(count).padStart(2, "0")}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section className="container-shell pb-14 md:pb-24">
        <div className="relative overflow-hidden rounded-[18px] bg-[var(--ink-navy)] p-6 text-white sm:p-10 md:p-14">
          <div className="absolute -right-16 -top-24 size-72 rounded-full border border-[var(--gold)]/30" aria-hidden="true" />
          <div className="relative grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
            <div>
              <p className="eyebrow text-[var(--gold)]">For business owners</p>
              <h2 className="display-title mt-4 max-w-[700px] text-[34px] md:text-[48px]">Make your next local customer easier to reach.</h2>
              <p className="mt-4 max-w-[60ch] text-[15px] leading-relaxed text-white/75">Create a free basic listing and submit it for review. Featured placement is configurable by the administrator; online payments are not connected in this release.</p>
            </div>
            <Link to="/owner" className="btn-primary w-full md:w-auto">Add your business <ArrowRight className="arrow-nudge" size={18} /></Link>
          </div>
        </div>
      </section>
    </>
  );
}
