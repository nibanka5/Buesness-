import { useMemo, useState, type FormEvent } from "react";
import { Link, useParams } from "react-router";
import { ArrowLeft, ArrowUpRight, BadgeCheck, CheckCircle2, Clock3, ExternalLink, Flag, Globe2, MapPin, MessageCircle, Phone, Send } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { usePageMeta } from "@/hooks/usePageMeta";
import { SampleBadge } from "@/components/SampleBadge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function BusinessProfilePage() {
  const { slug = "" } = useParams();
  const businessQuery = trpc.directory.bySlug.useQuery({ slug }, { retry: false });
  const business = businessQuery.data;
  const [inquiry, setInquiry] = useState({ name: "", email: "", phone: "", message: "" });
  const [report, setReport] = useState({ reason: "Incorrect contact details", details: "", email: "" });
  const [inquirySent, setInquirySent] = useState(false);
  const [reportSent, setReportSent] = useState(false);

  const inquiryMutation = trpc.directory.submitInquiry.useMutation({
    onSuccess: () => {
      setInquiry({ name: "", email: "", phone: "", message: "" });
      setInquirySent(true);
    },
  });
  const reportMutation = trpc.directory.reportListing.useMutation({
    onSuccess: () => {
      setReport({ reason: "Incorrect contact details", details: "", email: "" });
      setReportSent(true);
    },
  });

  const structuredData = useMemo(() => {
    if (!business || business.sample) return undefined;
    return {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      name: business.name,
      description: business.description,
      telephone: business.phone,
      address: { "@type": "PostalAddress", streetAddress: business.address, addressLocality: business.city, addressRegion: business.district, addressCountry: "LK" },
      url: business.website || window.location.href,
      image: business.photos.map((photo) => new URL(photo, window.location.origin).toString()),
      openingHours: business.openingHours,
    };
  }, [business]);

  usePageMeta(
    business ? `${business.name} — ${business.city} | Lanka Business Finder` : "Business Profile | Lanka Business Finder",
    business?.description.slice(0, 155) ?? "View local business details, services, opening hours and direct contact options.",
    structuredData,
  );

  function submitInquiry(event: FormEvent) {
    event.preventDefault();
    if (!business) return;
    setInquirySent(false);
    inquiryMutation.mutate({ listingId: business.id, ...inquiry });
  }

  function submitReport(event: FormEvent) {
    event.preventDefault();
    if (!business) return;
    setReportSent(false);
    reportMutation.mutate({ listingId: business.id, ...report });
  }

  if (businessQuery.isLoading) {
    return <div className="container-shell py-16"><div className="h-[420px] animate-pulse rounded-[18px] bg-[var(--line)]" /></div>;
  }

  if (!business) {
    return (
      <div className="container-shell py-20 text-center">
        <h1 className="display-title text-[38px]">This profile isn’t available.</h1>
        <p className="mt-3 text-[var(--muted-ink)]">It may have been removed or is still awaiting approval.</p>
        <Link to="/search" className="btn-primary mt-6">Search the directory</Link>
      </div>
    );
  }

  const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(business.mapQuery)}`;

  return (
    <>
      <section className="border-b border-[var(--line)] bg-white/50 py-6 md:py-10">
        <div className="container-shell">
          <Link to="/search" className="inline-flex min-h-11 items-center gap-2 text-[13px] text-[var(--muted-ink)] hover:text-[var(--ink-navy)]"><ArrowLeft size={16} /> Back to search</Link>
          <div className="mt-5 flex flex-wrap items-center gap-2">
            {business.sample && <SampleBadge />}
            {business.verified && <span className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-[var(--emerald-dark)]"><BadgeCheck size={16} /> Verified by administrator</span>}
            {business.featured && <span className="eyebrow text-[#806515]">Featured</span>}
          </div>
          <div className="mt-5 grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <p className="eyebrow text-[var(--emerald-dark)]">{business.category}</p>
              <h1 className="display-title mt-3 max-w-[900px] text-[40px] md:text-[62px]">{business.name}</h1>
              <p className="mt-4 flex items-center gap-2 text-[15px] text-[var(--muted-ink)]"><MapPin size={17} />{business.city}, {business.district}, Sri Lanka</p>
            </div>
            <div className="grid grid-cols-2 gap-2.5 sm:flex sm:flex-wrap">
              <a href={`tel:${business.phone.replace(/[^+\d]/g, "")}`} className="btn-primary"><Phone size={17} /> Call</a>
              <a href={`https://wa.me/${business.whatsapp}`} target="_blank" rel="noreferrer" className="btn-outline !bg-white"><MessageCircle size={17} /> WhatsApp</a>
              {business.website && <a href={business.website} target="_blank" rel="noreferrer" className="btn-outline !bg-white"><Globe2 size={17} /> Website</a>}
              <a href={mapUrl} target="_blank" rel="noreferrer" className="btn-outline !bg-white"><MapPin size={17} /> Directions</a>
            </div>
          </div>
          {business.sample && <p className="mt-5 max-w-[75ch] text-[12px] leading-relaxed text-[var(--muted-ink)]">This is a fictional sample business. Phone numbers, WhatsApp details, address and hours are placeholders for interface demonstration; they are not real business contact details.</p>}
        </div>
      </section>

      <div className="container-shell grid gap-10 py-10 md:py-14 lg:grid-cols-[minmax(0,1.35fr)_minmax(300px,.65fr)] lg:gap-14">
        <div>
          {business.photos.length > 0 && (
            <div className={`grid gap-3 ${business.photos.length > 1 ? "sm:grid-cols-2" : ""}`}>
              {business.photos.map((photo, index) => (
                <div key={photo} className={`overflow-hidden rounded-[16px] bg-[var(--line)] ${index === 0 && business.photos.length > 2 ? "sm:col-span-2" : ""}`}>
                  <img src={photo} alt={`${business.sample ? "Representative sample" : business.name} photo ${index + 1}`} className="aspect-[4/3] h-full w-full object-cover sm:aspect-[16/10]" width="1200" height="800" />
                </div>
              ))}
            </div>
          )}
          {business.sample && <p className="mt-2 text-[11px] text-[var(--muted-ink)]">Representative stock photography, not a photo of a real listed business.</p>}

          <section className="mt-10" aria-labelledby="about-business">
            <p className="eyebrow text-[var(--emerald-dark)]">About this business</p>
            <h2 id="about-business" className="mt-3 text-[28px] font-[590] tracking-[-0.04em]">What they offer</h2>
            <p className="mt-4 max-w-[70ch] whitespace-pre-line text-[16px] leading-[1.75] text-[var(--ink-secondary)]">{business.description}</p>
          </section>

          <section className="mt-9 border-t border-[var(--line)] pt-8" aria-labelledby="services-heading">
            <h2 id="services-heading" className="text-[22px] font-[590] tracking-[-0.035em]">Services</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {business.services.map((service) => <span key={service} className="chip !min-h-11 !px-3.5 !text-[14px]">{service}</span>)}
            </div>
          </section>

          <section id="inquiry" className="mt-12 scroll-mt-28 rounded-[16px] border border-[var(--line)] bg-white p-5 sm:p-7" aria-labelledby="inquiry-heading">
            <p className="eyebrow text-[var(--emerald-dark)]">Direct enquiry</p>
            <h2 id="inquiry-heading" className="mt-3 text-[28px] font-[590] tracking-[-0.04em]">Ask {business.name} a question</h2>
            <p className="mt-2 text-[14px] leading-relaxed text-[var(--muted-ink)]">Your enquiry is saved for the directory team to route to the business. No message is sent externally in this demo.</p>
            <form onSubmit={submitInquiry} className="mt-6 grid gap-4 sm:grid-cols-2">
              <label><span className="field-label">Your name *</span><input className="field" required minLength={2} maxLength={100} value={inquiry.name} onChange={(e) => setInquiry({ ...inquiry, name: e.target.value })} autoComplete="name" /></label>
              <label><span className="field-label">Email *</span><input className="field" required type="email" value={inquiry.email} onChange={(e) => setInquiry({ ...inquiry, email: e.target.value })} autoComplete="email" /></label>
              <label className="sm:col-span-2"><span className="field-label">Phone (optional)</span><input className="field" value={inquiry.phone} onChange={(e) => setInquiry({ ...inquiry, phone: e.target.value })} inputMode="tel" autoComplete="tel" /></label>
              <label className="sm:col-span-2"><span className="field-label">How can they help? *</span><textarea className="field" required minLength={10} maxLength={1600} value={inquiry.message} onChange={(e) => setInquiry({ ...inquiry, message: e.target.value })} /></label>
              {inquiryMutation.error && <p role="alert" className="text-sm text-red-700 sm:col-span-2">{inquiryMutation.error.message}</p>}
              {inquirySent && <p role="status" className="flex items-center gap-2 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-900 sm:col-span-2"><CheckCircle2 size={18} /> Enquiry saved successfully.</p>}
              <button type="submit" className="btn-primary sm:col-span-2" disabled={inquiryMutation.isPending}>{inquiryMutation.isPending ? "Saving enquiry…" : <>Send enquiry <Send size={17} /></>}</button>
            </form>
          </section>
        </div>

        <aside className="space-y-7 lg:pt-1">
          <section className="border-t-2 border-[var(--ink-navy)] pt-5">
            <h2 className="text-[20px] font-[600] tracking-[-0.03em]">Contact & location</h2>
            <dl className="mt-5 space-y-5 text-[14px]">
              <div><dt className="eyebrow text-[var(--muted-ink)]">Phone</dt><dd className="mt-1.5"><a className="inline-flex min-h-11 items-center font-medium text-[var(--emerald-dark)] underline-offset-4 hover:underline" href={`tel:${business.phone.replace(/[^+\d]/g, "")}`}>{business.phone}</a></dd></div>
              <div><dt className="eyebrow text-[var(--muted-ink)]">Address</dt><dd className="mt-1.5 leading-relaxed text-[var(--ink-secondary)]">{business.address}</dd></div>
              <div><dt className="eyebrow text-[var(--muted-ink)]">Opening hours</dt><dd className="mt-1.5 flex gap-2 leading-relaxed text-[var(--ink-secondary)]"><Clock3 size={17} className="mt-1 flex-none" />{business.openingHours}</dd></div>
            </dl>
            <a href={mapUrl} target="_blank" rel="noreferrer" className="btn-outline mt-6 w-full">Open Google Maps <ArrowUpRight size={17} /></a>
          </section>

          <section className="rounded-[14px] bg-[var(--emerald-soft)] p-5">
            <h2 className="text-[17px] font-[600]">Keep information accurate</h2>
            <p className="mt-2 text-[13px] leading-relaxed text-[var(--ink-secondary)]">Spotted an incorrect number, address or opening time? Send a report for administrator review.</p>
            <Dialog>
              <DialogTrigger asChild><button className="btn-outline mt-4 w-full !bg-white"><Flag size={16} /> Report incorrect information</button></DialogTrigger>
              <DialogContent className="max-h-[90dvh] overflow-y-auto bg-[var(--paper)] sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle>Report incorrect information</DialogTitle>
                  <DialogDescription>Tell the administrator what needs to be reviewed for {business.name}.</DialogDescription>
                </DialogHeader>
                <form onSubmit={submitReport} className="space-y-4">
                  <label className="block"><span className="field-label">Issue *</span><select className="field" value={report.reason} onChange={(e) => setReport({ ...report, reason: e.target.value })}><option>Incorrect contact details</option><option>Incorrect address</option><option>Incorrect opening hours</option><option>Business closed or unavailable</option><option>Inappropriate content</option><option>Other</option></select></label>
                  <label className="block"><span className="field-label">What should be corrected? *</span><textarea className="field" required minLength={10} maxLength={1200} value={report.details} onChange={(e) => setReport({ ...report, details: e.target.value })} /></label>
                  <label className="block"><span className="field-label">Your email (optional)</span><input className="field" type="email" value={report.email} onChange={(e) => setReport({ ...report, email: e.target.value })} /></label>
                  {reportMutation.error && <p role="alert" className="text-sm text-red-700">{reportMutation.error.message}</p>}
                  {reportSent && <p role="status" className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-900">Report saved for review.</p>}
                  <button type="submit" className="btn-primary w-full" disabled={reportMutation.isPending}>{reportMutation.isPending ? "Saving…" : "Submit report"}</button>
                </form>
              </DialogContent>
            </Dialog>
          </section>

          {business.website && <a href={business.website} target="_blank" rel="noreferrer" className="flex min-h-12 items-center justify-between border-y border-[var(--line)] text-[14px] font-medium text-[var(--emerald-dark)]">Visit business website <ExternalLink size={16} /></a>}
        </aside>
      </div>
    </>
  );
}
