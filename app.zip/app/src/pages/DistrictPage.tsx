import { Link, useParams } from "react-router";
import { ArrowLeft, ArrowRight, MapPin } from "lucide-react";
import { CATEGORIES, DISTRICTS, fromSlug } from "@contracts/directory";
import { trpc } from "@/providers/trpc";
import { usePageMeta } from "@/hooks/usePageMeta";
import { SearchPanel } from "@/components/SearchPanel";
import { BusinessCard, BusinessCardSkeleton } from "@/components/BusinessCard";

export default function DistrictPage() {
  const { slug = "" } = useParams();
  const district = fromSlug(slug, DISTRICTS) as (typeof DISTRICTS)[number] | undefined;
  const results = trpc.directory.search.useQuery(
    { q: "", district, limit: 60 },
    { enabled: Boolean(district) },
  );
  usePageMeta(
    district ? `Businesses in ${district} | Lanka Business Finder` : "District not found | Lanka Business Finder",
    district ? `Find local businesses and services in ${district}, Sri Lanka. Browse sample profiles with contact and direction options.` : "The requested district could not be found.",
  );

  if (!district) {
    return <div className="container-shell py-20"><h1 className="display-title text-4xl">District not found.</h1><Link to="/districts" className="btn-primary mt-6">View all districts</Link></div>;
  }

  return (
    <>
      <section className="border-b border-[var(--line)] bg-[var(--emerald-soft)]/50 py-10 md:py-16">
        <div className="container-shell">
          <Link to="/districts" className="inline-flex min-h-11 items-center gap-2 text-[13px] text-[var(--muted-ink)] hover:text-[var(--ink-navy)]"><ArrowLeft size={16} /> All districts</Link>
          <div className="mt-7 flex items-center gap-2 text-[var(--emerald-dark)]"><MapPin size={19} /><span className="eyebrow">Sri Lanka</span></div>
          <h1 className="display-title mt-3 text-[42px] md:text-[62px]">{district}</h1>
          <p className="mb-7 mt-4 max-w-[60ch] text-[16px] text-[var(--muted-ink)]">Discover local businesses and services in {district}. Search results in this release are fictional sample profiles.</p>
          <SearchPanel initialDistrict={district} compact />
        </div>
      </section>
      <section className="container-shell py-10 md:py-16">
        <div className="mb-7 flex items-end justify-between gap-4 border-b border-[var(--line)] pb-5">
          <div>
            <h2 className="text-[22px] font-[600] tracking-[-0.035em]">{results.data?.length ?? 0} sample {results.data?.length === 1 ? "profile" : "profiles"}</h2>
            <p className="mt-1 text-[13px] text-[var(--muted-ink)]">Unverified demonstration data.</p>
          </div>
          <Link to={`/search?district=${encodeURIComponent(district)}`} className="hidden min-h-11 items-center gap-2 text-sm font-semibold text-[var(--emerald-dark)] sm:inline-flex">Refine search <ArrowRight size={16} /></Link>
        </div>
        <div className="grid gap-4 lg:grid-cols-2">
          {results.isLoading && Array.from({ length: 2 }, (_, i) => <BusinessCardSkeleton key={i} />)}
          {results.data?.map((listing) => <BusinessCard key={listing.id} listing={listing} />)}
        </div>
        {!results.isLoading && results.data?.length === 0 && (
          <div className="border-y border-[var(--line)] py-12 text-center">
            <h2 className="text-2xl font-semibold tracking-[-0.03em]">No sample listings in {district} yet.</h2>
            <p className="mx-auto mt-3 max-w-[55ch] text-[15px] text-[var(--muted-ink)]">Try a nearby district or submit a real business for administrator review.</p>
            <Link to="/owner" className="btn-primary mt-6">Add a business in {district}</Link>
          </div>
        )}
        <div className="mt-12">
          <h2 className="eyebrow text-[var(--muted-ink)]">Browse {district} by category</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {CATEGORIES.map((category) => <Link key={category} to={`/search?district=${encodeURIComponent(district)}&category=${encodeURIComponent(category)}`} className="chip min-h-11 hover:border-[var(--emerald)]">{category}</Link>)}
          </div>
        </div>
      </section>
    </>
  );
}
