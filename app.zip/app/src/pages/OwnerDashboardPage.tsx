import { useState } from "react";
import { Link } from "react-router";
import { ArrowLeft, Building2, CheckCircle2, Clock3, Edit3, LogOut, Plus, ShieldCheck, XCircle } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { usePageMeta } from "@/hooks/usePageMeta";
import { ListingForm, toListingInput } from "@/components/ListingForm";
import type { DirectoryListing } from "@/types/directory";
import type { ListingInput } from "@contracts/directory";

export default function OwnerDashboardPage() {
  usePageMeta("My Business Listings | Lanka Business Finder", "Submit and manage your Sri Lankan business directory profiles.");
  const { user, isLoading, isAuthenticated, logout } = useAuth({ redirectOnUnauthenticated: true });
  const [mode, setMode] = useState<"list" | "create" | "edit">("list");
  const [selected, setSelected] = useState<DirectoryListing | null>(null);
  const [success, setSuccess] = useState("");
  const utils = trpc.useUtils();
  const listingsQuery = trpc.owner.mine.useQuery(undefined, { enabled: isAuthenticated });
  const metadata = trpc.directory.metadata.useQuery();

  const createMutation = trpc.owner.create.useMutation({
    onSuccess: async () => {
      setSuccess("Listing submitted. It is now pending administrator review and is not publicly visible yet.");
      await utils.owner.mine.invalidate();
      await utils.directory.metadata.invalidate();
    },
  });
  const updateMutation = trpc.owner.update.useMutation({
    onSuccess: async () => {
      setSuccess("Changes saved. Your listing has returned to pending review and must be approved again.");
      await utils.owner.mine.invalidate();
      await utils.directory.search.invalidate();
    },
  });

  function submit(data: ListingInput) {
    setSuccess("");
    if (mode === "edit" && selected) updateMutation.mutate({ id: selected.id, data });
    else createMutation.mutate(data);
  }

  if (isLoading || !isAuthenticated) {
    return <div className="container-shell py-16"><div className="h-56 animate-pulse rounded-[16px] bg-[var(--line)]" /></div>;
  }

  const activeMutation = mode === "edit" ? updateMutation : createMutation;
  const settings = metadata.data?.settings;

  return (
    <div className="container-shell py-8 md:py-12">
      <div className="flex flex-col gap-5 border-b border-[var(--line)] pb-7 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="eyebrow text-[var(--emerald-dark)]">Business owner workspace</p>
          <h1 className="display-title mt-2 text-[36px] md:text-[48px]">Welcome{user?.name ? `, ${user.name}` : ""}.</h1>
          <p className="mt-2 text-[14px] text-[var(--muted-ink)]">Manage your profiles and review their approval status.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {user?.role === "admin" && <Link to="/admin" className="btn-outline"><ShieldCheck size={17} /> Admin</Link>}
          <button className="btn-outline" onClick={logout}><LogOut size={17} /> Sign out</button>
        </div>
      </div>

      {mode === "list" ? (
        <div className="grid gap-10 py-8 lg:grid-cols-[1fr_300px]">
          <section>
            <div className="mb-6 flex items-center justify-between gap-4">
              <h2 className="text-[22px] font-[600] tracking-[-0.03em]">Your listings</h2>
              <button className="btn-primary" onClick={() => { setMode("create"); setSelected(null); setSuccess(""); createMutation.reset(); updateMutation.reset(); }}><Plus size={17} /> New listing</button>
            </div>
            {listingsQuery.isLoading && <div className="h-40 animate-pulse rounded-[14px] bg-[var(--line)]" />}
            {listingsQuery.data?.length === 0 && (
              <div className="rounded-[16px] border border-dashed border-[var(--line)] bg-white/45 px-6 py-12 text-center">
                <Building2 className="mx-auto text-[var(--emerald-dark)]" size={34} strokeWidth={1.5} />
                <h3 className="mt-4 text-xl font-semibold tracking-[-0.03em]">No business profiles yet</h3>
                <p className="mx-auto mt-2 max-w-[48ch] text-[14px] text-[var(--muted-ink)]">Start with a free basic listing. An administrator will review it before it appears publicly.</p>
                <button className="btn-primary mt-5" onClick={() => setMode("create")}>Create your first listing</button>
              </div>
            )}
            <div className="space-y-3">
              {listingsQuery.data?.map((listing) => (
                <article key={listing.id} className="rounded-[14px] border border-[var(--line)] bg-white p-5">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`chip ${listing.status === "approved" ? "!border-emerald-200 !bg-emerald-50 !text-emerald-900" : listing.status === "rejected" ? "!border-red-200 !bg-red-50 !text-red-800" : "!border-amber-200 !bg-amber-50 !text-amber-900"}`}>
                          {listing.status === "approved" ? <CheckCircle2 size={14} /> : listing.status === "rejected" ? <XCircle size={14} /> : <Clock3 size={14} />}
                          {listing.status}
                        </span>
                        {listing.requestedFeatured && <span className="chip">Featured requested</span>}
                      </div>
                      <h3 className="mt-3 text-[21px] font-[600] tracking-[-0.035em]">{listing.name}</h3>
                      <p className="mt-1 text-[13px] text-[var(--muted-ink)]">{listing.category} · {listing.city}, {listing.district}</p>
                    </div>
                    <button className="btn-outline self-start" onClick={() => { setSelected(listing); setMode("edit"); setSuccess(""); updateMutation.reset(); }}><Edit3 size={16} /> Edit profile</button>
                  </div>
                  {listing.status === "approved" && <Link to={`/business/${listing.slug}`} className="mt-3 inline-flex min-h-11 items-center text-[13px] font-semibold text-[var(--emerald-dark)]">View public profile</Link>}
                </article>
              ))}
            </div>
          </section>
          <aside className="space-y-6">
            <div className="rounded-[14px] bg-[var(--emerald-soft)] p-5">
              <h2 className="font-semibold">Free basic listing</h2>
              <p className="mt-2 text-[13px] leading-relaxed text-[var(--ink-secondary)]">Every submission starts pending. Editing an approved profile sends it back for review.</p>
            </div>
            <div className="border-y border-[var(--line)] py-5">
              <h2 className="font-semibold">Featured placement</h2>
              <p className="mt-2 text-[13px] leading-relaxed text-[var(--muted-ink)]">Currently configured at LKR {settings?.featuredPriceLkr?.toLocaleString() ?? "2,500"} for {settings?.featuredDurationDays ?? 30} days. Request it in your listing; the administrator approves placement manually.</p>
              <p className="mt-2 text-[12px] font-medium text-[#806515]">Online payment integration is a future setup item. No payment is collected here.</p>
            </div>
          </aside>
        </div>
      ) : (
        <section className="mx-auto max-w-4xl py-8">
          <button className="mb-6 inline-flex min-h-11 items-center gap-2 text-[14px] font-medium text-[var(--muted-ink)]" onClick={() => { setMode("list"); setSelected(null); setSuccess(""); }}><ArrowLeft size={17} /> Back to my listings</button>
          <div className="mb-8">
            <p className="eyebrow text-[var(--emerald-dark)]">{mode === "edit" ? "Edit profile" : "Free basic listing"}</p>
            <h2 className="display-title mt-3 text-[34px] md:text-[44px]">{mode === "edit" ? selected?.name : "Tell customers about your business."}</h2>
            <p className="mt-3 max-w-[65ch] text-[14px] leading-relaxed text-[var(--muted-ink)]">Provide accurate information. Submissions are validated and reviewed before publication; verification is never automatic.</p>
          </div>
          <div className="rounded-[16px] border border-[var(--line)] bg-white p-5 sm:p-7">
            <ListingForm
              key={selected?.id ?? mode}
              initialData={selected ? toListingInput(selected) : undefined}
              onSubmit={submit}
              submitting={activeMutation.isPending}
              error={activeMutation.error?.message}
              success={success}
              submitLabel={mode === "edit" ? "Save and resubmit for review" : "Submit for administrator review"}
              onCancel={() => { setMode("list"); setSelected(null); }}
            />
          </div>
        </section>
      )}
    </div>
  );
}
