import { useEffect, useState } from "react";
import { Link } from "react-router";
import { ArrowLeft, BadgeCheck, Check, Edit3, Eye, ShieldCheck, Star, StarOff, Trash2, X } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { usePageMeta } from "@/hooks/usePageMeta";
import { ListingForm, toListingInput } from "@/components/ListingForm";
import { SampleBadge } from "@/components/SampleBadge";
import type { DirectoryListing } from "@/types/directory";
import type { ListingInput } from "@contracts/directory";

type Filter = "all" | "pending" | "approved" | "rejected";

export default function AdminDashboardPage() {
  usePageMeta("Directory Administration | Lanka Business Finder", "Approve, verify, feature, edit and remove directory listings.");
  const { user, isLoading } = useAuth({ redirectOnUnauthenticated: true });
  const isAdmin = user?.role === "admin";
  const [filter, setFilter] = useState<Filter>("all");
  const [editing, setEditing] = useState<DirectoryListing | null>(null);
  const [notice, setNotice] = useState("");
  const [settings, setSettings] = useState({ featuredPriceLkr: 2500, featuredDurationDays: 30 });
  const utils = trpc.useUtils();
  const listingsQuery = trpc.admin.listings.useQuery(undefined, { enabled: isAdmin });
  const metadata = trpc.directory.metadata.useQuery();

  useEffect(() => {
    if (metadata.data?.settings) {
      setSettings({
        featuredPriceLkr: metadata.data.settings.featuredPriceLkr,
        featuredDurationDays: metadata.data.settings.featuredDurationDays,
      });
    }
  }, [metadata.data]);

  async function refreshDirectory() {
    await Promise.all([
      utils.admin.listings.invalidate(),
      utils.directory.search.invalidate(),
      utils.directory.metadata.invalidate(),
    ]);
  }

  const moderate = trpc.admin.moderate.useMutation({
    onSuccess: async (_, input) => {
      setNotice(`Listing ${input.action === "remove" ? "removed" : `${input.action}d`} successfully.`);
      await refreshDirectory();
    },
  });
  const updateListing = trpc.admin.updateListing.useMutation({
    onSuccess: async () => {
      setNotice("Listing details updated successfully.");
      setEditing(null);
      await refreshDirectory();
    },
  });
  const updateSettings = trpc.admin.updateSettings.useMutation({
    onSuccess: async () => {
      setNotice("Featured listing configuration saved.");
      await utils.directory.metadata.invalidate();
    },
  });

  if (isLoading) return <div className="container-shell py-16"><div className="h-56 animate-pulse rounded-[16px] bg-[var(--line)]" /></div>;
  if (!isAdmin) {
    return <div className="container-shell py-20 text-center"><ShieldCheck className="mx-auto text-[var(--muted-ink)]" size={40} /><h1 className="display-title mt-5 text-4xl">Administrator access required.</h1><p className="mt-3 text-[var(--muted-ink)]">This account does not have permission to moderate listings.</p><Link to="/owner" className="btn-primary mt-6">Go to owner workspace</Link></div>;
  }

  const filtered = listingsQuery.data?.filter((listing) => filter === "all" || listing.status === filter) ?? [];
  const pendingCount = listingsQuery.data?.filter((listing) => listing.status === "pending").length ?? 0;

  return (
    <div className="container-shell py-8 md:py-12">
      <div className="flex flex-col gap-5 border-b border-[var(--line)] pb-7 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="eyebrow text-[var(--emerald-dark)]">Protected administration</p>
          <h1 className="display-title mt-2 text-[36px] md:text-[48px]">Directory control.</h1>
          <p className="mt-2 text-[14px] text-[var(--muted-ink)]">Approve, edit, verify and remove listings. Verification is always a manual action.</p>
        </div>
        <Link to="/owner" className="btn-outline self-start"><ArrowLeft size={17} /> Owner workspace</Link>
      </div>

      {notice && <div role="status" className="mt-6 flex items-center justify-between gap-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900">{notice}<button className="flex size-11 items-center justify-center" onClick={() => setNotice("")} aria-label="Dismiss notification"><X size={17} /></button></div>}

      {editing ? (
        <section className="mx-auto max-w-4xl py-8">
          <button className="mb-6 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-[var(--muted-ink)]" onClick={() => setEditing(null)}><ArrowLeft size={17} /> Back to moderation</button>
          <p className="eyebrow text-[var(--emerald-dark)]">Administrator edit</p>
          <h2 className="display-title mt-3 text-[36px]">{editing.name}</h2>
          <p className="mb-7 mt-3 text-[14px] text-[var(--muted-ink)]">Editing here does not automatically verify the listing. Use the verification control separately.</p>
          <div className="rounded-[16px] border border-[var(--line)] bg-white p-5 sm:p-7">
            <ListingForm initialData={toListingInput(editing)} onSubmit={(data: ListingInput) => updateListing.mutate({ id: editing.id, data })} submitting={updateListing.isPending} error={updateListing.error?.message} submitLabel="Save listing details" onCancel={() => setEditing(null)} />
          </div>
        </section>
      ) : (
        <div className="grid gap-10 py-8 xl:grid-cols-[minmax(0,1fr)_300px]">
          <section>
            <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <h2 className="text-[22px] font-[600] tracking-[-0.03em]">Listings <span className="font-mono text-sm text-[var(--muted-ink)]">({pendingCount} pending)</span></h2>
              <div className="flex flex-wrap gap-1 rounded-[10px] border border-[var(--line)] bg-white p-1">
                {(["all", "pending", "approved", "rejected"] as Filter[]).map((item) => <button key={item} onClick={() => setFilter(item)} className={`min-h-11 rounded-[7px] px-3 text-[13px] font-medium capitalize ${filter === item ? "bg-[var(--ink-navy)] text-white" : "text-[var(--muted-ink)] hover:bg-[var(--paper)]"}`}>{item}</button>)}
              </div>
            </div>
            {listingsQuery.isLoading && <div className="h-52 animate-pulse rounded-[14px] bg-[var(--line)]" />}
            <div className="space-y-4">
              {filtered.map((listing) => (
                <article key={listing.id} className="rounded-[14px] border border-[var(--line)] bg-white p-5">
                  <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="chip capitalize">{listing.status}</span>
                        {listing.sample && <SampleBadge compact />}
                        {listing.verified && <span className="inline-flex items-center gap-1 text-[12px] font-semibold text-[var(--emerald-dark)]"><BadgeCheck size={14} /> Verified</span>}
                        {listing.featured && <span className="inline-flex items-center gap-1 text-[12px] font-semibold text-[#806515]"><Star size={13} /> Featured</span>}
                      </div>
                      <h3 className="mt-3 text-[22px] font-[610] tracking-[-0.035em]">{listing.name}</h3>
                      <p className="mt-1 text-[13px] text-[var(--muted-ink)]">{listing.category} · {listing.city}, {listing.district}</p>
                      <p className="mt-2 max-w-[65ch] line-clamp-2 text-[13px] leading-relaxed text-[var(--ink-secondary)]">{listing.description}</p>
                    </div>
                    <div className="flex flex-none gap-2">
                      {listing.status === "approved" && <Link to={`/business/${listing.slug}`} className="btn-outline !px-3" aria-label={`View ${listing.name}`}><Eye size={17} /></Link>}
                      <button className="btn-outline !px-3" onClick={() => { setEditing(listing); updateListing.reset(); }} aria-label={`Edit ${listing.name}`}><Edit3 size={17} /></button>
                    </div>
                  </div>
                  <div className="mt-5 flex flex-wrap gap-2 border-t border-[var(--line)] pt-4">
                    {listing.status !== "approved" ? <button className="btn-primary !min-h-11 !px-3 !text-[13px]" disabled={moderate.isPending} onClick={() => moderate.mutate({ id: listing.id, action: "approve" })}><Check size={15} /> Approve</button> : <button className="btn-outline !min-h-11 !px-3 !text-[13px]" disabled={moderate.isPending} onClick={() => moderate.mutate({ id: listing.id, action: "reject" })}><X size={15} /> Reject</button>}
                    <button className="btn-outline !min-h-11 !px-3 !text-[13px]" disabled={moderate.isPending} onClick={() => moderate.mutate({ id: listing.id, action: listing.verified ? "unverify" : "verify" })}><BadgeCheck size={15} /> {listing.verified ? "Unverify" : "Verify"}</button>
                    <button className="btn-outline !min-h-11 !px-3 !text-[13px]" disabled={moderate.isPending} onClick={() => moderate.mutate({ id: listing.id, action: listing.featured ? "unfeature" : "feature" })}>{listing.featured ? <StarOff size={15} /> : <Star size={15} />}{listing.featured ? "Unfeature" : "Feature"}</button>
                    <button className="btn-danger !min-h-11 !px-3 !text-[13px]" disabled={moderate.isPending} onClick={() => { if (window.confirm(`Remove ${listing.name}? This cannot be undone.`)) moderate.mutate({ id: listing.id, action: "remove" }); }}><Trash2 size={15} /> Remove</button>
                  </div>
                </article>
              ))}
            </div>
            {moderate.error && <p role="alert" className="mt-4 rounded-lg bg-red-50 p-3 text-sm text-red-800">{moderate.error.message}</p>}
            {!listingsQuery.isLoading && filtered.length === 0 && <p className="rounded-[14px] border border-dashed border-[var(--line)] p-10 text-center text-[var(--muted-ink)]">No {filter === "all" ? "" : filter} listings.</p>}
          </section>

          <aside className="space-y-6">
            <section className="rounded-[14px] border border-[var(--line)] bg-white p-5">
              <p className="eyebrow text-[var(--emerald-dark)]">Featured configuration</p>
              <h2 className="mt-2 text-xl font-semibold tracking-[-0.03em]">Placement settings</h2>
              <form className="mt-5 space-y-4" onSubmit={(event) => { event.preventDefault(); updateSettings.mutate(settings); }}>
                <label className="block"><span className="field-label">Price (LKR)</span><input className="field" type="number" min={0} max={1000000} required value={settings.featuredPriceLkr} onChange={(e) => setSettings({ ...settings, featuredPriceLkr: Number(e.target.value) })} /></label>
                <label className="block"><span className="field-label">Duration (days)</span><input className="field" type="number" min={1} max={365} required value={settings.featuredDurationDays} onChange={(e) => setSettings({ ...settings, featuredDurationDays: Number(e.target.value) })} /></label>
                {updateSettings.error && <p role="alert" className="text-sm text-red-700">{updateSettings.error.message}</p>}
                <button className="btn-primary w-full" disabled={updateSettings.isPending}>{updateSettings.isPending ? "Saving…" : "Save configuration"}</button>
              </form>
              <p className="mt-4 text-[12px] leading-relaxed text-[#806515]">Payment collection is not integrated. Featuring is a manual admin action; add a payment provider before charging businesses.</p>
            </section>
            <section className="rounded-[14px] bg-[var(--emerald-soft)] p-5">
              <h2 className="font-semibold">Moderation checklist</h2>
              <ul className="mt-3 space-y-2 text-[13px] leading-relaxed text-[var(--ink-secondary)]">
                <li>Confirm contact details with the owner before verifying.</li>
                <li>Check sample flags and never verify fictional data.</li>
                <li>Review edited approved listings again.</li>
                <li>Only feature approved, accurate profiles.</li>
              </ul>
            </section>
          </aside>
        </div>
      )}
    </div>
  );
}
