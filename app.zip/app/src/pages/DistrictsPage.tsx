import { Link } from "react-router";
import { ArrowUpRight, MapPin } from "lucide-react";
import { DISTRICTS, slugify } from "@contracts/directory";
import { trpc } from "@/providers/trpc";
import { usePageMeta } from "@/hooks/usePageMeta";

export default function DistrictsPage() {
  usePageMeta("All 25 Sri Lankan Districts | Lanka Business Finder", "Browse local businesses across every administrative district in Sri Lanka.");
  const metadata = trpc.directory.metadata.useQuery();

  return (
    <section className="container-shell py-10 md:py-16">
      <div className="grid gap-6 md:grid-cols-[1fr_.8fr] md:items-end">
        <div>
          <p className="eyebrow text-[var(--emerald-dark)]">Islandwide coverage</p>
          <h1 className="display-title mt-3 text-[40px] md:text-[58px]">All 25 districts.<br />One local directory.</h1>
        </div>
        <p className="max-w-[55ch] text-[16px] text-[var(--muted-ink)] md:justify-self-end">Choose a district to explore nearby businesses, then refine by category or keyword. Demo counts represent fictional sample data only.</p>
      </div>
      <div className="mt-10 grid grid-cols-1 border-l border-t border-[var(--line)] min-[480px]:grid-cols-2 md:grid-cols-3 lg:grid-cols-5">
        {DISTRICTS.map((district) => {
          const count = metadata.data?.districtCounts[district as keyof typeof metadata.data.districtCounts] ?? 0;
          return (
            <Link key={district} to={`/district/${slugify(district)}`} className="group flex min-h-[142px] flex-col justify-between border-b border-r border-[var(--line)] bg-white/40 p-5 transition-colors hover:bg-[var(--emerald-soft)]">
              <div className="flex items-start justify-between">
                <MapPin size={20} strokeWidth={1.6} className="text-[var(--emerald-dark)]" />
                <ArrowUpRight size={16} className="arrow-nudge text-[var(--muted-ink)]" />
              </div>
              <div>
                <h2 className="text-[18px] font-[590] leading-tight tracking-[-0.03em]">{district}</h2>
                <p className="mt-1.5 font-mono text-[11px] text-[var(--muted-ink)]">{count} sample {count === 1 ? "profile" : "profiles"}</p>
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
