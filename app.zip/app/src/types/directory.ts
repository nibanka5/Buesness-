import type { trpc } from "@/providers/trpc";

type SearchQueryResult = ReturnType<typeof trpc.directory.search.useQuery>;
export type DirectoryListing = NonNullable<SearchQueryResult["data"]>[number];
