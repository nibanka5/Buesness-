import { useEffect, useState, type FormEvent } from "react";
import { CheckCircle2, LoaderCircle } from "lucide-react";
import { CATEGORIES, DISTRICTS, EMPTY_LISTING, type ListingInput } from "@contracts/directory";
import type { DirectoryListing } from "@/types/directory";

export function toListingInput(listing: DirectoryListing): ListingInput {
  return {
    name: listing.name,
    category: listing.category as ListingInput["category"],
    description: listing.description,
    phone: listing.phone,
    whatsapp: listing.whatsapp,
    website: listing.website ?? "",
    address: listing.address,
    district: listing.district as ListingInput["district"],
    city: listing.city,
    openingHours: listing.openingHours,
    services: listing.services,
    photos: listing.photos,
    mapQuery: listing.mapQuery,
    requestedFeatured: listing.requestedFeatured,
  };
}

type ListingFormProps = {
  initialData?: ListingInput;
  onSubmit: (data: ListingInput) => void;
  submitting?: boolean;
  error?: string;
  success?: string;
  submitLabel?: string;
  onCancel?: () => void;
};

export function ListingForm({ initialData, onSubmit, submitting = false, error, success, submitLabel = "Submit for review", onCancel }: ListingFormProps) {
  const [form, setForm] = useState<ListingInput>(initialData ?? EMPTY_LISTING);
  const [servicesText, setServicesText] = useState((initialData?.services ?? []).join(", "));
  const [photosText, setPhotosText] = useState((initialData?.photos ?? []).join("\n"));

  useEffect(() => {
    const next = initialData ?? EMPTY_LISTING;
    setForm(next);
    setServicesText(next.services.join(", "));
    setPhotosText(next.photos.join("\n"));
  }, [initialData]);

  function set<K extends keyof ListingInput>(key: K, value: ListingInput[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    onSubmit({
      ...form,
      name: form.name.trim(),
      city: form.city.trim(),
      website: form.website.trim(),
      services: servicesText.split(",").map((item) => item.trim()).filter(Boolean),
      photos: photosText.split("\n").map((item) => item.trim()).filter(Boolean),
    });
  }

  return (
    <form onSubmit={submit} className="space-y-7" noValidate={false}>
      <div className="grid gap-5 md:grid-cols-2">
        <label className="md:col-span-2">
          <span className="field-label">Business name *</span>
          <input className="field" required minLength={2} maxLength={120} value={form.name} onChange={(e) => set("name", e.target.value)} autoComplete="organization" />
        </label>
        <label>
          <span className="field-label">Category *</span>
          <select className="field" value={form.category} onChange={(e) => set("category", e.target.value as ListingInput["category"])}>
            {CATEGORIES.map((category) => <option key={category}>{category}</option>)}
          </select>
        </label>
        <label>
          <span className="field-label">District *</span>
          <select className="field" value={form.district} onChange={(e) => set("district", e.target.value as ListingInput["district"])}>
            {DISTRICTS.map((district) => <option key={district}>{district}</option>)}
          </select>
        </label>
        <label>
          <span className="field-label">City / town *</span>
          <input className="field" required minLength={2} maxLength={80} value={form.city} onChange={(e) => set("city", e.target.value)} autoComplete="address-level2" />
        </label>
        <label>
          <span className="field-label">Contact number *</span>
          <input className="field" required value={form.phone} onChange={(e) => set("phone", e.target.value)} inputMode="tel" autoComplete="tel" placeholder="+94 77 123 4567" />
        </label>
        <label>
          <span className="field-label">WhatsApp number *</span>
          <input className="field" required value={form.whatsapp} onChange={(e) => set("whatsapp", e.target.value.replace(/\D/g, ""))} inputMode="numeric" placeholder="94771234567" />
          <span className="mt-1 block text-xs text-[var(--muted-ink)]">Country code and digits only.</span>
        </label>
        <label>
          <span className="field-label">Website</span>
          <input className="field" type="url" value={form.website} onChange={(e) => set("website", e.target.value)} inputMode="url" placeholder="https://yourbusiness.lk" />
        </label>
        <label className="md:col-span-2">
          <span className="field-label">Street address *</span>
          <input className="field" required minLength={5} maxLength={240} value={form.address} onChange={(e) => set("address", e.target.value)} autoComplete="street-address" />
        </label>
        <label className="md:col-span-2">
          <span className="field-label">Google Maps search / directions *</span>
          <input className="field" required minLength={2} maxLength={240} value={form.mapQuery} onChange={(e) => set("mapQuery", e.target.value)} placeholder="Business name, city, Sri Lanka" />
        </label>
      </div>

      <div className="form-section grid gap-5">
        <label>
          <span className="field-label">Description *</span>
          <textarea className="field" required minLength={30} maxLength={1600} value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Tell customers what you offer, who you serve and what makes your business useful." />
          <span className="mt-1 block text-xs text-[var(--muted-ink)]">{form.description.length}/1600 characters · Minimum 30</span>
        </label>
        <label>
          <span className="field-label">Services *</span>
          <input className="field" required value={servicesText} onChange={(e) => setServicesText(e.target.value)} placeholder="Consultations, Home visits, Online support" />
          <span className="mt-1 block text-xs text-[var(--muted-ink)]">Separate up to 12 services with commas.</span>
        </label>
        <label>
          <span className="field-label">Opening hours *</span>
          <textarea className="field !min-h-[88px]" required minLength={3} maxLength={500} value={form.openingHours} onChange={(e) => set("openingHours", e.target.value)} placeholder="Monday–Friday, 09:00–17:00" />
        </label>
        <label>
          <span className="field-label">Photo URLs</span>
          <textarea className="field !min-h-[88px] font-mono !text-[13px]" value={photosText} onChange={(e) => setPhotosText(e.target.value)} placeholder="https://yourbusiness.lk/photo.webp" />
          <span className="mt-1 block text-xs text-[var(--muted-ink)]">One secure https:// URL per line, up to 6. Direct image uploads are a future setup item.</span>
        </label>
      </div>

      <label className="form-section flex min-h-14 cursor-pointer items-start gap-3 !pt-5">
        <input type="checkbox" className="mt-1 size-5 accent-[var(--emerald)]" checked={form.requestedFeatured} onChange={(e) => set("requestedFeatured", e.target.checked)} />
        <span>
          <span className="block text-[15px] font-semibold">Request featured placement</span>
          <span className="mt-1 block text-[13px] leading-relaxed text-[var(--muted-ink)]">Basic listings are free. Featured requests are reviewed by an administrator; no online payment is collected in this version.</span>
        </span>
      </label>

      {error && <div role="alert" className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">{error}</div>}
      {success && <div role="status" className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900"><CheckCircle2 size={18} />{success}</div>}
      <div className="flex flex-col-reverse gap-3 sm:flex-row">
        {onCancel && <button type="button" className="btn-outline" onClick={onCancel}>Cancel</button>}
        <button type="submit" className="btn-primary flex-1" disabled={submitting}>
          {submitting && <LoaderCircle className="animate-spin" size={18} />}
          {submitting ? "Saving…" : submitLabel}
        </button>
      </div>
    </form>
  );
}
