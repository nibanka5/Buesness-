import { Link } from "react-router";
import { ArrowUpRight, BadgeCheck, Building2, Clock3, MapPin } from "lucide-react";
import type { DirectoryListing } from "@/types/directory";
import { SampleBadge } from "./SampleBadge";

export function BusinessCard({ listing }: { listing: DirectoryListing }) {
  return (
    <Link
      to={`/business/${listing.slug}`}
      className="business-row group flex min-h-[154px] gap-4 rounded-[14px] border border-[var(--line)] bg-white p-3.5 sm:gap-5 sm:p-4"
      aria-label={`View ${listing.name}`}
    >
      <div className="relative h-[118px] w-[92px] flex-none overflow-hidden rounded-[10px] bg-[var(--emerald-soft)] sm:h-[132px] sm:w-[144px]">
        {listing.photos[0] ? (
          <img src={listing.photos[0]} alt="" className="h-full w-full object-cover transition-transform duration-200 group-hover:scale-[1.025]" loading="lazy" width="300" height="260" />
        ) : (
          <div className="flex h-full items-center justify-center text-[var(--emerald-dark)]"><Building2 size={30} aria-hidden="true" /></div>
        )}
      </div>
      <div className="min-w-0 flex-1 py-0.5">
        <div className="flex items-start justify-between gap-2">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            {listing.sample && <SampleBadge compact />}
            {listing.verified && <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[var(--emerald-dark)]"><BadgeCheck size={13} /> Verified</span>}
            {listing.featured && <span className="font-mono text-[10px] uppercase tracking-wider text-[#806515]">Featured</span>}
          </div>
          <ArrowUpRight className="arrow-nudge mt-1 flex-none text-[var(--muted-ink)]" size={18} aria-hidden="true" />
        </div>
        <h3 className="mt-2 text-[18px] font-[610] leading-[1.2] tracking-[-0.035em] sm:text-[20px]">{listing.name}</h3>
        <p className="mt-1 text-[13px] font-medium text-[var(--emerald-dark)]">{listing.category}</p>
        <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-[var(--muted-ink)]">
          <span className="inline-flex items-center gap-1.5"><MapPin size={13} aria-hidden="true" />{listing.city}, {listing.district}</span>
          <span className="hidden items-center gap-1.5 sm:inline-flex"><Clock3 size={13} aria-hidden="true" />See hours</span>
        </div>
        <p className="mt-2 hidden line-clamp-2 max-w-[65ch] text-[13px] leading-[1.5] text-[var(--ink-secondary)] md:block">{listing.description}</p>
      </div>
    </Link>
  );
}

export function BusinessCardSkeleton() {
  return (
    <div className="flex min-h-[154px] animate-pulse gap-4 rounded-[14px] border border-[var(--line)] bg-white p-3.5">
      <div className="h-[118px] w-[92px] rounded-[10px] bg-[var(--line)] sm:h-[132px] sm:w-[144px]" />
      <div className="flex-1 space-y-3 py-2">
        <div className="h-4 w-20 rounded bg-[var(--gold-soft)]" />
        <div className="h-6 w-3/4 rounded bg-[var(--line)]" />
        <div className="h-4 w-1/3 rounded bg-[var(--line)]" />
        <div className="h-4 w-1/2 rounded bg-[var(--line)]" />
      </div>
    </div>
  );
}
