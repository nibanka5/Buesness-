import { useEffect, useState, type ReactNode } from "react";
import { Link, NavLink, useLocation } from "react-router";
import { Building2, Home, LayoutGrid, Menu, Search, ShieldCheck, UserRound } from "lucide-react";
import { Sheet, SheetContent, SheetDescription, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/useAuth";
import { Logo } from "./Logo";

const navItems = [
  { to: "/search", label: "Find businesses" },
  { to: "/categories", label: "Categories" },
  { to: "/districts", label: "Districts" },
  { to: "/contact", label: "Contact" },
];

export function Layout({ children }: { children: ReactNode }) {
  const { user, isLoading } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => setMenuOpen(false), [location.pathname]);

  return (
    <div className="min-h-dvh bg-[var(--paper)] text-[var(--ink-navy)]">
      <a href="#main-content" className="fixed left-3 top-3 z-[60] -translate-y-24 rounded-lg bg-white px-4 py-3 font-semibold text-[var(--ink-navy)] shadow-lg transition-transform focus:translate-y-0">
        Skip to content
      </a>
      <header className="glass-header sticky top-0 z-40 border-b border-[var(--line)]">
        <div className="container-shell flex h-[72px] items-center justify-between gap-4">
          <Logo />
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Main navigation">
            {navItems.map((item) => (
              <NavLink key={item.to} to={item.to} className={({ isActive }) => `relative flex min-h-11 items-center text-[14px] font-[530] transition-colors ${isActive ? "text-[var(--emerald-dark)]" : "text-[var(--ink-secondary)] hover:text-[var(--ink-navy)]"}`}>
                {item.label}
              </NavLink>
            ))}
          </nav>
          <div className="hidden items-center gap-3 md:flex">
            {!isLoading && (
              <Link to={user ? "/owner" : "/login"} className="flex min-h-11 items-center gap-2 px-2 text-[14px] font-[550] text-[var(--ink-secondary)] hover:text-[var(--emerald-dark)]">
                <UserRound size={17} aria-hidden="true" />
                {user ? "My listings" : "Sign in"}
              </Link>
            )}
            <Link to="/owner" className="btn-primary !min-h-11 !px-4">
              <Building2 size={17} aria-hidden="true" /> Add your business
            </Link>
          </div>
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <button className="flex size-11 items-center justify-center rounded-lg border border-[var(--line)] md:hidden" aria-label="Open menu">
                <Menu size={22} aria-hidden="true" />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[min(88vw,360px)] border-l-[var(--line)] bg-[var(--paper)] p-0">
              <div className="border-b border-[var(--line)] p-5 pr-14">
                <SheetTitle className="text-left text-lg tracking-[-0.03em]">Explore Lanka</SheetTitle>
                <SheetDescription className="text-left text-sm">Local businesses, direct connections.</SheetDescription>
              </div>
              <nav className="flex flex-col p-3" aria-label="Mobile navigation">
                {navItems.map((item) => (
                  <Link key={item.to} to={item.to} className="flex min-h-12 items-center rounded-lg px-4 text-base font-medium hover:bg-[var(--emerald-soft)]">
                    {item.label}
                  </Link>
                ))}
                <Link to="/owner" className="mt-3 flex min-h-12 items-center gap-2 rounded-lg bg-[var(--emerald)] px-4 font-semibold text-white">
                  <Building2 size={18} /> Add your business
                </Link>
                <Link to={user ? "/owner" : "/login"} className="mt-2 flex min-h-12 items-center gap-2 rounded-lg px-4 font-medium">
                  <UserRound size={18} /> {user ? "My listings" : "Sign in / Register"}
                </Link>
                {user?.role === "admin" && (
                  <Link to="/admin" className="mt-1 flex min-h-12 items-center gap-2 rounded-lg px-4 font-medium">
                    <ShieldCheck size={18} /> Admin dashboard
                  </Link>
                )}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      <main id="main-content" className="pb-24 md:pb-0">{children}</main>

      <footer className="overflow-hidden bg-[var(--ink-navy-deep)] pb-10 pt-14 text-white md:pt-20">
        <div className="container-shell">
          <div className="grid gap-10 border-b border-white/15 pb-12 md:grid-cols-[1.2fr_.8fr] md:items-end">
            <div>
              <Logo light />
              <p className="mt-5 max-w-md text-[17px] leading-relaxed text-white/80">Find Local. Connect Directly. Grow Together.</p>
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-[15px] text-white/80 md:justify-self-end">
              <Link className="flex min-h-11 items-center hover:text-white" to="/owner">List a business</Link>
              <Link className="flex min-h-11 items-center hover:text-white" to="/contact">Contact</Link>
              <Link className="flex min-h-11 items-center hover:text-white" to="/privacy">Privacy</Link>
              <Link className="flex min-h-11 items-center hover:text-white" to="/terms">Terms</Link>
            </div>
          </div>
          <div className="pointer-events-none select-none whitespace-nowrap py-8 text-[clamp(54px,11.5vw,160px)] font-[540] leading-[.85] tracking-[-0.075em] text-white/[0.07]" aria-hidden="true">
            LANKA FINDER
          </div>
          <div className="flex flex-col gap-2 text-[13px] text-white/65 md:flex-row md:items-center md:justify-between">
            <p>© {new Date().getFullYear()} Lanka Business Finder</p>
            <p>Demo release · Sample profiles are fictional and unverified.</p>
          </div>
        </div>
      </footer>

      <nav className="mobile-safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-[var(--line)] bg-white/95 pt-1 backdrop-blur-lg md:hidden" aria-label="Quick navigation">
        <div className="grid grid-cols-4">
          {[
            { to: "/", label: "Home", icon: Home },
            { to: "/search", label: "Search", icon: Search },
            { to: "/categories", label: "Categories", icon: LayoutGrid },
            { to: "/owner", label: "Account", icon: UserRound },
          ].map((item) => (
            <NavLink key={item.to} to={item.to} end={item.to === "/"} className={({ isActive }) => `flex min-h-[52px] flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${isActive ? "text-[var(--emerald-dark)]" : "text-[var(--muted-ink)]"}`}>
              <item.icon size={20} strokeWidth={1.8} aria-hidden="true" />
              {item.label}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}
