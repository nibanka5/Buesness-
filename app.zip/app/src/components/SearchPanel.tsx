import { useEffect, useState, type FormEvent } from "react";
import { useNavigate } from "react-router";
import { Search } from "lucide-react";
import { CATEGORIES, DISTRICTS } from "@contracts/directory";

type SearchPanelProps = {
  initialQuery?: string;
  initialCategory?: string;
  initialDistrict?: string;
  compact?: boolean;
};

export function SearchPanel({ initialQuery = "", initialCategory = "", initialDistrict = "", compact = false }: SearchPanelProps) {
  const navigate = useNavigate();
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState(initialCategory);
  const [district, setDistrict] = useState(initialDistrict);

  useEffect(() => {
    setQuery(initialQuery);
    setCategory(initialCategory);
    setDistrict(initialDistrict);
  }, [initialQuery, initialCategory, initialDistrict]);

  function submit(event: FormEvent) {
    event.preventDefault();
    const params = new URLSearchParams();
    if (query.trim()) params.set("q", query.trim());
    if (category) params.set("category", category);
    if (district) params.set("district", district);
    navigate(`/search${params.size ? `?${params.toString()}` : ""}`);
  }

  return (
    <form onSubmit={submit} className={`rounded-[16px] bg-white shadow-[0_24px_70px_-35px_rgba(0,0,0,.55)] ${compact ? "p-3" : "p-3.5 md:p-4"}`} role="search">
      <div className="grid gap-2.5 md:grid-cols-[minmax(0,1.5fr)_minmax(150px,.7fr)_minmax(140px,.65fr)_auto]">
        <label className="relative block">
          <span className="sr-only">What business or service are you looking for?</span>
          <Search className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--emerald-dark)]" size={20} aria-hidden="true" />
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            className="field !border-transparent !bg-[var(--paper)] !pl-11"
            placeholder="What business or service are you looking for?"
            maxLength={100}
          />
        </label>
        <label>
          <span className="sr-only">Category</span>
          <select className="field !border-transparent !bg-[var(--paper)] text-[14px]" value={category} onChange={(event) => setCategory(event.target.value)}>
            <option value="">All categories</option>
            {CATEGORIES.map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
        </label>
        <label>
          <span className="sr-only">District</span>
          <select className="field !border-transparent !bg-[var(--paper)] text-[14px]" value={district} onChange={(event) => setDistrict(event.target.value)}>
            <option value="">All districts</option>
            {DISTRICTS.map((item) => <option key={item} value={item}>{item}</option>)}
          </select>
        </label>
        <button type="submit" className="btn-primary md:min-w-[112px]">
          <Search size={18} aria-hidden="true" /> Search
        </button>
      </div>
    </form>
  );
}
