import { Link } from "react-router";

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="inline-flex min-h-11 items-center gap-2.5" aria-label="Lanka Business Finder home">
      <svg width="31" height="31" viewBox="0 0 32 32" fill="none" aria-hidden="true">
        <path d="M16 3.5c-6.3 0-11.5 4.8-11.5 10.8 0 7.7 9.7 13.5 11.1 14.3.2.1.5.1.7 0 1.4-.8 11.2-6.6 11.2-14.3C27.5 8.3 22.3 3.5 16 3.5Z" stroke={light ? "#fff" : "#071a30"} strokeWidth="1.8" />
        <path d="M11.5 10.5v10h9" stroke="#0a8a63" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="21.5" cy="10.5" r="2" fill="#c9a227" />
      </svg>
      <span className={`text-[15px] font-[620] leading-[1.05] tracking-[-0.035em] ${light ? "text-white" : "text-[#071a30]"}`}>
        Lanka<br />Business Finder
      </span>
    </Link>
  );
}
