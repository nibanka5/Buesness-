import { FlaskConical } from "lucide-react";

export function SampleBadge({ compact = false }: { compact?: boolean }) {
  return (
    <span className="sample-badge">
      <FlaskConical size={12} aria-hidden="true" />
      {compact ? "Sample" : "Fictional sample · Not verified"}
    </span>
  );
}
