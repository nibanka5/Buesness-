import { z } from "zod";

export const CATEGORIES = [
  "Restaurants",
  "Hotels",
  "Doctors",
  "Education",
  "Beauty Salons",
  "Hardware",
  "Construction",
  "Real Estate",
  "Vehicle Services",
  "IT Services",
  "Shops",
  "Professional Services",
] as const;

export const DISTRICTS = [
  "Ampara",
  "Anuradhapura",
  "Badulla",
  "Batticaloa",
  "Colombo",
  "Galle",
  "Gampaha",
  "Hambantota",
  "Jaffna",
  "Kalutara",
  "Kandy",
  "Kegalle",
  "Kilinochchi",
  "Kurunegala",
  "Mannar",
  "Matale",
  "Matara",
  "Monaragala",
  "Mullaitivu",
  "Nuwara Eliya",
  "Polonnaruwa",
  "Puttalam",
  "Ratnapura",
  "Trincomalee",
  "Vavuniya",
] as const;

export function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export function fromSlug(value: string, items: readonly string[]) {
  return items.find((item) => slugify(item) === value);
}

const httpsUrl = z
  .string()
  .url("Enter a complete URL")
  .startsWith("https://", "Use a secure https:// URL");

export const listingInputSchema = z.object({
  name: z.string().trim().min(2).max(120),
  category: z.enum(CATEGORIES),
  description: z.string().trim().min(30).max(1600),
  phone: z
    .string()
    .trim()
    .regex(/^\+?[0-9 ()-]{7,20}$/, "Enter a valid contact number"),
  whatsapp: z
    .string()
    .trim()
    .regex(/^[0-9]{7,15}$/, "Use country code and digits only"),
  website: z.union([httpsUrl, z.literal("")]),
  address: z.string().trim().min(5).max(240),
  district: z.enum(DISTRICTS),
  city: z.string().trim().min(2).max(80),
  openingHours: z.string().trim().min(3).max(500),
  services: z.array(z.string().trim().min(2).max(80)).min(1).max(12),
  photos: z.array(z.union([httpsUrl, z.string().regex(/^\/images\/[a-z0-9-]+\.webp$/)])).max(6),
  mapQuery: z.string().trim().min(2).max(240),
  requestedFeatured: z.boolean(),
});

export type ListingInput = z.infer<typeof listingInputSchema>;

export const EMPTY_LISTING: ListingInput = {
  name: "",
  category: "Restaurants",
  description: "",
  phone: "",
  whatsapp: "",
  website: "",
  address: "",
  district: "Colombo",
  city: "",
  openingHours: "",
  services: [],
  photos: [],
  mapQuery: "",
  requestedFeatured: false,
};
